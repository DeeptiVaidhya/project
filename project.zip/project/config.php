<?php

/*$servername = "sitesdemo.db.10546729.hostedresource.com";
$username = "sitesdemo";
$password = "Demo#Sites00";
$dbname = "sitesdemo";*/
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rail";

$conn = mysqli_connect($servername, $username, $password, $dbname);
/*$conn = mysqli_connect("localhost", "user_fairsale", "Z$ik&}h,}F=@", "db_fairsale");*/

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?> 
