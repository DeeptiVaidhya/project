<!DOCTYPE html>
<?php 
 include("config.php");
 ?>
<html>
	<head>
	<title>My Page</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	</head>
<body>
<?php 
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://api.coursera.org/api/courses.v1');

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	$contents = curl_exec($ch);

	//echo $contents;


	$b=json_decode($contents);

	$i=0;

        if(isset($_POST['save']))
			{
				echo $course_id = $_POST['course_id'];
				echo $course_name = $_POST['course_name'];
				echo $course_type = $_POST['course_type'];
				$sql = mysqli_query($conn,"INSERT INTO course_detail (course_id,course_name,course_type)
	VALUES ('$course_id','$course_name','$course_type')");

					if (mysqli_query($conn, $sql)) 
					{
						echo "<div class='alert alert-success'><b>Succesfully Add</b></div>";
					} 
	    				else 
					{
						echo "<div class='alert alert-success'><b>Succesfully Add</b></div>";
					}
       }
?>
<div class="container">
        <button type="button" class="btn btn-success"><a href="list-view.php">View Courses</a></button>
	<table class="table table-striped table-bordered">
        	<thead>
                        <tr>
                            <th>Course ID</th>
                            <th>Course Name</th>
			    <th>Course Type</th>
                            <th>Save Data</th>
                        </tr>
                        
			<?php 
			while($b->{'elements'}[$i])
			{
                               echo '<form action="" method="POST">';
				echo '<tr><td>'.$id=$b->{'elements'}[$i]->{'id'}.'<input type="hidden" name="course_id" value="'.$b->{'elements'}[$i]->{'id'}.'">'.'</td>';
				echo '<td>'.$name=$b->{'elements'}[$i]->{'name'}.'<input type="hidden" name="course_name" value="'.$b->{'elements'}[$i]->{'name'}.'">'.'</td>';
				echo '<td>'.$type=$b->{'elements'}[$i]->{'courseType'}.'<input type="hidden" name="course_type" value="'.$b->{'elements'}[$i]->{'courseType'}.'">'.'</td>';
				echo '<td><input type="submit" name="save" value="Save"></td></tr>';
                                echo '</form>';
				$i++;
			}
                        
			?>
                        
 		<thead>
	</table>
</div>
</body>
</html>
