<!DOCTYPE html>
<?php 
 include("config.php");
 ?>
<html>
	<head>
	<title>My Page</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	</head>
<body>

<div class="container">
       <h2>View Course Name</h2>
       <ul> 
     <?php 
              $result=mysqli_query($conn,"SELECT * FROM course_detail");
			while($row=mysqli_fetch_array($result))
			{
     ?>
   
        	 <li><?php echo $row['course_name']; ?></li>  
      <?php }?> 
     </ul>
</div>
</body>
</html>
