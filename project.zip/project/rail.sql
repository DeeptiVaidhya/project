-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2018 at 12:26 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rail`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_detail`
--

CREATE TABLE `course_detail` (
  `id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_detail`
--

INSERT INTO `course_detail` (`id`, `course_id`, `course_name`, `course_type`) VALUES
(1, 'ct7G8DVLEeWfzhKP8GtZlQ', 'Build a Modern Computer from First Principles: From Nand to Tetris (Project-Centered Course)', 'v2.ondemand'),
(2, 'ct7G8DVLEeWfzhKP8GtZlQ', 'Build a Modern Computer from First Principles: From Nand to Tetris (Project-Centered Course)', 'v2.ondemand'),
(3, '69Bku0KoEeWZtA4u62x6lQ', 'Gamification', 'v2.ondemand'),
(4, '0HiU7Oe4EeWTAQ4yevf_oQ', 'Dealing With Missing Data', 'v2.ondemand'),
(5, '5zjIsJq-EeW_wArffOXkOw', 'Vital Signs: Understanding What the Body Is Telling Us', 'v2.ondemand'),
(6, 'opX5uCGvEearhhL0e-FIDw', 'ÐÑÑ‚Ñ€Ð¾Ñ„Ð¸Ð·Ð¸ÐºÐ°: Ð¾Ñ‚ Ð·Ð²ÐµÐ·Ð´ Ð´Ð¾ Ð³Ñ€Ð°Ð½Ð¸Ñ† Ð’ÑÐµÐ»ÐµÐ½Ð½Ð¾Ð¹', 'v2.ondemand'),
(7, 'rajsT7UJEeWl_hJObLDVwQ', 'å‰ªè¾‘ï¼šåƒç¼–å‰§ä¸€æ ·å‰ªè¾‘', 'v2.ondemand'),
(8, 'lfKT5sS3EeWhPQ55lNYVVQ', 'From Climate Science to Action', 'v2.ondemand');

-- --------------------------------------------------------
